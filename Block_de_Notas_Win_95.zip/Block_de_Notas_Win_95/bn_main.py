import os
import tkinter as tk
from tkinter import simpledialog, messagebox, filedialog
from tkinter import ttk

NOTAS_DIR = "notas"

if not os.path.exists(NOTAS_DIR):
    os.makedirs(NOTAS_DIR)

root = tk.Tk()
root.title("Bloc de Notas - Windows 95 Style")
root.geometry("900x600")
root.configure(bg='#C0C0C0')

# Estilo tipo Windows 95
style = ttk.Style()
style.theme_use('clam')
style.configure("Treeview", background="#C0C0C0", fieldbackground="#C0C0C0", foreground="black", font=('Courier', 10))
style.configure("TButton", background="#C0C0C0", foreground="black", font=('Courier', 10), relief="flat")
style.map("TButton", background=[('active', '#A0A0A0')])

# Marco izquierdo para lista de archivos
left_frame = tk.Frame(root, width=200, bg='#C0C0C0')
left_frame.pack(side=tk.LEFT, fill=tk.Y)

# Marco derecho para contenido
right_frame = tk.Frame(root, bg='#C0C0C0')
right_frame.pack(side=tk.RIGHT, expand=True, fill=tk.BOTH)

# Lista de notas
nota_lista_label = tk.Label(left_frame, text="Notas", bg="#C0C0C0", fg="black", font=('Courier', 10))
nota_lista_label.pack(pady=5)
nota_lista = tk.Listbox(left_frame, bg="#FFFFFF", fg="black", font=('Courier', 10))
nota_lista.pack(fill=tk.BOTH, expand=True, padx=5)

# Vista de pizarra
pizarra_visible = False
pizarra_frame = tk.Frame(right_frame, bg='#C0C0C0')

# Texto de nota
texto_nota = tk.Text(right_frame, wrap=tk.WORD, font=('Courier', 12), bg="white", fg="black")
texto_nota.pack(expand=True, fill=tk.BOTH)

nota_actual = None

# Funciones

def cargar_notas():
    nota_lista.delete(0, tk.END)
    for archivo in os.listdir(NOTAS_DIR):
        if archivo.endswith(".txt"):
            nota_lista.insert(tk.END, archivo)

def mostrar_nota(event):
    global nota_actual
    seleccion = nota_lista.curselection()
    if seleccion:
        nota = nota_lista.get(seleccion)
        ruta = os.path.join(NOTAS_DIR, nota)
        with open(ruta, 'r') as f:
            contenido = f.read()
        texto_nota.delete(1.0, tk.END)
        texto_nota.insert(tk.END, contenido)
        nota_actual = nota
        texto_nota.pack(expand=True, fill=tk.BOTH)
        pizarra_frame.pack_forget()


def nueva_nota():
    global nota_actual
    nombre = simpledialog.askstring("Nombre de la nota", "¿Cómo quieres llamar esta nota?")
    if nombre:
        if not nombre.endswith(".txt"):
            nombre += ".txt"
        nota_actual = nombre
        texto_nota.delete(1.0, tk.END)
        guardar_nota()
        cargar_notas()


def eliminar_nota():
    global nota_actual
    if nota_actual:
        confirm = messagebox.askyesno("Eliminar", f"¿Eliminar la nota '{nota_actual}'?")
        if confirm:
            os.remove(os.path.join(NOTAS_DIR, nota_actual))
            nota_actual = None
            texto_nota.delete(1.0, tk.END)
            cargar_notas()


def guardar_nota():
    global nota_actual
    if nota_actual:
        ruta = os.path.join(NOTAS_DIR, nota_actual)
        with open(ruta, 'w') as f:
            f.write(texto_nota.get(1.0, tk.END))


def autosave():
    guardar_nota()
    root.after(2000, autosave)


def ver_pizarra():
    global pizarra_visible
    if not pizarra_visible:
        texto_nota.pack_forget()
        pizarra_frame.pack(expand=True, fill=tk.BOTH)
        for widget in pizarra_frame.winfo_children():
            widget.destroy()
        for archivo in os.listdir(NOTAS_DIR):
            if archivo.endswith(".txt"):
                with open(os.path.join(NOTAS_DIR, archivo), 'r') as f:
                    preview = f.read(50).replace("\n", " ")
                post_it = tk.Button(pizarra_frame, text=preview + "...", wraplength=150, command=lambda a=archivo: abrir_postit(a), bg="#FFFF88", fg="black", relief="flat", font=('Courier', 9), height=5, width=20)
                post_it.pack(padx=10, pady=10, anchor="nw")
        pizarra_visible = True
    else:
        pizarra_frame.pack_forget()
        texto_nota.pack(expand=True, fill=tk.BOTH)
        pizarra_visible = False


def abrir_postit(nombre_archivo):
    global nota_actual
    ruta = os.path.join(NOTAS_DIR, nombre_archivo)
    with open(ruta, 'r') as f:
        contenido = f.read()
    texto_nota.delete(1.0, tk.END)
    texto_nota.insert(tk.END, contenido)
    nota_actual = nombre_archivo
    pizarra_frame.pack_forget()
    texto_nota.pack(expand=True, fill=tk.BOTH)


# Botones
btn_nueva = ttk.Button(left_frame, text="Nueva nota", command=nueva_nota)
btn_nueva.pack(pady=5, padx=5, fill=tk.X)
btn_eliminar = ttk.Button(left_frame, text="Eliminar nota", command=eliminar_nota)
btn_eliminar.pack(pady=5, padx=5, fill=tk.X)
btn_pizarra = ttk.Button(left_frame, text="Ver pizarra", command=ver_pizarra)
btn_pizarra.pack(pady=5, padx=5, fill=tk.X)

nota_lista.bind('<<ListboxSelect>>', mostrar_nota)

cargar_notas()
autosave()
root.mainloop()
